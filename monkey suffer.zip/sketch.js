var monkey , monkey_running , monkeyover;
var banana ,bananaImage, obstacle, obstacleImage;
var foodGroup, obstacleGroup;
var score;
var highscore;
var collect;
var ground;
var PLAY = 1;
var END = 0;
var gameState = PLAY;


function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png");
  
  monkeyover = loadImage("sprite_7.png");
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas(1400,600);
  
  monkey = createSprite(80,500,20,20);
  monkey.addAnimation("moving",monkey_running);
  monkey.scale = 0.25;

  ground = createSprite(600,575,1700,10);
  
  monkey.setCollider("rectangle" , 0 , 0 , 400 , 550);
  
  foodGroup =  createGroup();
  obstacleGroup = createGroup();
  
  score = 0;
  collect = 0;
  highscore = 0;
}


function draw() {
  background("skyBlue");
  
  stroke("white");
  fill("black");
  textSize(25);
  text("Score: " + score,1100,50);
  text("Collect🍌: " + collect,1100,110);
  text("HighScore: " + highscore,1100,80);
  
  if(gameState === PLAY){
    
    // movement of monkey.
    if(keyDown("space") && monkey.y >= 350){
      monkey.velocityY = -20;
    }
    
    // gravity bro
    monkey.velocityY = monkey.velocityY + 0.8;

    // functions.
    spawnFruit();
    spawnObstacle();
    
    // scoring.
    score = score + Math.round(getFrameRate()/60);
    
    if(foodGroup.isTouching(monkey)){
      collect++;
      foodGroup.destroyEach();
    }
    
    // lose condition.
    if(obstacleGroup.isTouching(monkey) && gameState ===            PLAY){
      gameState = END;
    }
  }
  
  if(gameState === END){
    
     stroke("black");
     fill("red");
     textSize(75);
     text("GAME OVER",400,300);
     textSize(20);
     text("click monkey to restart",525,340);
    
     monkey.velocityY = 0;
     
    
     foodGroup.setLifetimeEach(-1);
     obstacleGroup.setLifetimeEach(-1);
    
     foodGroup.setVelocityXEach(0);
     obstacleGroup.setVelocityXEach(0);
    
     if(score > highscore){
       highscore = score;
       }
  }

  if(mousePressedOver(monkey)){
     reset();
  }
  monkey.collide(ground);
  

  
  drawSprites();
}

function reset() {
  gameState = PLAY;
  foodGroup.destroyEach();
  obstacleGroup.destroyEach();
  score = 0;
}

function spawnFruit() {
  if(frameCount % 100 === 0) {
     banana = createSprite(1200,Math.round(random(100,525)),20,20);
    //console.log(banana.y);
    banana.addImage("B",bananaImage);
    banana.scale = 0.18;
    banana.velocityX = -(10 + 3* score/100);
    banana.lifetime = 200;
    
    foodGroup.add(banana);
  }
}

function spawnObstacle() {
  if(frameCount % 300 === 0 ){
    obstacle = createSprite(1200,520,40,40);
    obstacle.addImage("rr",obstacleImage);
    obstacle.scale = 0.3;
    obstacle.velocityX = -(12 + 3* score/100);
    obstacle.lifetime = 120;
    
    obstacleGroup.add(obstacle);
  }
}




